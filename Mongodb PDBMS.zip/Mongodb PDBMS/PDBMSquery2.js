const { MongoClient } = require('mongodb');

async function complexSearchCriterion() {
  const client = new MongoClient('mongodb://localhost:27017/pdbms', { useNewUrlParser: true, useUnifiedTopology: true });

  try {
    await client.connect();

    const db = client.db('pdbms');
    const demandforecastCollection = db.collection('demandforecast');

    const result = await demandforecastCollection.aggregate([
      {
        $match: {
          $and: [
            { forescasted_demand: { $gt: 10 } },
            { confidence_level: { $gte: 90 } }
          ]
        }
      }
    ]).toArray();

    console.log(`Complex Search Criterion Result: ${JSON.stringify(result)}`);
  } finally {
    await client.close();
  }
}

complexSearchCriterion();
