const { MongoClient } = require('mongodb'); // Import MongoClient from the mongodb package

async function query1() {
  const client = new MongoClient('mongodb://localhost:27017/pdbms', { useNewUrlParser: true, useUnifiedTopology: true });

  try {
    await client.connect();

    const db = client.db('pdbms');
    const salestransactionCollection = db.collection('salestransaction');

    const result = await salestransactionCollection.aggregate([
      {
        $lookup: {
          from: "Product",
          let: { productId: "$productID" },
          pipeline: [
            {
              $match: {
                $expr: { $eq: ["$productID", "$$productId"] }
              }
            }
          ],
          as: "product"
        }
      },
      {
        $unwind: "$product"
      },
      {
        $group: {
          _id: "$product.product_category",
          totalRevenue: { $sum: "$sales_revenue" }
        }
      }
    ]).toArray();

    console.log(`Query1: Total sales revenue by product category is: ${JSON.stringify(result)}`);
  } finally {
    await client.close();
  }
}

query1();

