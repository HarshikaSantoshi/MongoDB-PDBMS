const { MongoClient } = require('mongodb');

async function disableProductsWithLowRatings() {
  const client = new MongoClient('mongodb://localhost:27017/pdbms', { useNewUrlParser: true, useUnifiedTopology: true });

  try {
    await client.connect();

    const db = client.db('pdbms');
    const productCollection = db.collection('Product');

    await productCollection.updateMany(
      { rating: { $lt: 1 } },
      { $set: { disabled: true } }
    );

    console.log(`Disabled Products with Low Ratings.`);
  } finally {
    await client.close();
  }
}

disableProductsWithLowRatings();
