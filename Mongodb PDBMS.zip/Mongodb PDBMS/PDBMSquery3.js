const { MongoClient } = require('mongodb');

async function updateDocumentBasedOnQueryParameter(productId, enable) {
  const client = new MongoClient('mongodb://localhost:27017/pdbms', { useNewUrlParser: true, useUnifiedTopology: true });

  try {
    await client.connect();

    const db = client.db('pdbms');
    const productCollection = db.collection('Product');

    const updateField = enable ? { $set: { isEnabled: true } } : { $unset: { isEnabled: '' } };

    const result = await productCollection.updateOne({ productID: productId }, updateField);

    console.log(`${result.modifiedCount} document updated: Product ${productId} ${enable ? 'enabled' : 'disabled'}.`);
  } finally {
    await client.close();
  }
}
updateDocumentBasedOnQueryParameter('3', true);

// Example usage: updateDocumentBasedOnQueryParameter('prod123', true);
