const { MongoClient } = require('mongodb');

async function countDocumentsForSpecificUser(userId) {
  const client = new MongoClient('mongodb://localhost:27017/pdbms', { useNewUrlParser: true, useUnifiedTopology: true });

  try {
    await client.connect();

    const db = client.db('pdbms');
    const salestransactionCollection = db.collection('salestransaction'); // Replace with the correct collection name

    const result = await salestransactionCollection.countDocuments({ productID: userId });

    console.log(`Number of Sales Transactions for User ${userId}: ${result}`);
  } finally {
    await client.close();
  }
}
countDocumentsForSpecificUser(30);


